<?php


namespace App\Controller;


use App\Entity\Entry;
use App\Entity\Salida;
use App\Repository\EntryRepository;
use App\Repository\SalidaRepository;
use http\Env\Response;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Knp\Snappy\Pdf;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ReporteController extends AbstractController
{

    /**
     * @Route("/reportes", name="reporte_index")
     */
    public function index(SalidaRepository $salidaRepository, EntryRepository $entryRepository, Request $request, Pdf $pdf)
    {

        $date1 = null;
        $date2 = null;
        $date3 = null;
        $salidas = [];
        $entradas = [];
        if (!empty($request->query->get('date1')) && !empty($request->query->get('date2')) ||
            !empty($request->query->get('date3'))) {
            $date1 = $request->query->get('date1');
            $date2 = $request->query->get('date2');
            $date3 = $request->query->get('date3');

            /** @var Salida $salidas */
            $salidas = $salidaRepository->findAllBetweenReporteDesc($date1, $date2, $date3);
            /** @var Entry $entradas */
            $entradas = $entryRepository->findAllBetweenReporteDesc($date1, $date2, $date3);
        }


        if ($request->getMethod() == Request::METHOD_POST) {
            $html = $this->renderView('pdf/pdf.html.twig', [
                'fecha' => $date3,
                'fechaentre' => $date1 . '-' . $date2,
                'salidas' => $salidas,
                'entradas' => $entradas,
            ]);
            $filename = 'reporte.pdf';
            $pdf->setTimeout(60);

            return new PdfResponse(
                $pdf->getOutputFromHtml($html),
                200,
                array(
                    'Content-Type' => 'application/pdf',
                    'Content-Disposition' => 'inline; filename="' . $filename . '.pdf"'
                )
            );
        }

        return $this->render('reporte/reportes.html.twig', [
            "salidas" => $salidas,
            "entradas" => $entradas
        ]);
    }


    /**
     * @Route ("/generate-pdf", name="app_generate_pdf")
     * @param Pdf $pdf
     */
    public function downloadSpecifications(SalidaRepository $salidaRepository,
                                           EntryRepository $entryRepository, Pdf $pdf, Request $request)
    {

        $date1 = null;
        $date2 = null;
        $date3 = null;

        if ($request->query->has('date1')) $date3 = $request->query->get('date1');
        if ($request->query->has('date2')) $date3 = $request->query->get('date2');
        if ($request->query->has('date3')) $date3 = $request->query->get('date3');


        $salidas = [];
        $entradas = [];

        /** @var Salida $salidas */
        $salidas = $salidaRepository->findAllBetweenReporteDesc($date1, $date2, $date3);

        /** @var Entry $entradas */
        $entradas = $entryRepository->findAllBetweenReporteDesc($date1, $date2, $date3);

        $html = $this->renderView('pdf/pdf.html.twig', [
            'fecha' => $date3,
            'fechaentre' => $date1 . '-' . $date2,
            'salidas' => $salidas,
            'entradas' => $entradas,
        ]);
        $filename = 'reporte.pdf';
        $pdf->setTimeout(60);

        return new PdfResponse(
            $pdf->getOutputFromHtml($html),
            200,
            array(
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="' . $filename . '.pdf"'
            )
        );
    }
}